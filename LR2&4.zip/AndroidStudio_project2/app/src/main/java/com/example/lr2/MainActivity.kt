package com.example.lr2

import android.content.Intent
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private lateinit var switchButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        textView = findViewById(R.id.textView)
        registerForContextMenu(textView)

        switchButton = findViewById(R.id.switchButton)
        switchButton.setOnClickListener {
            showConfirmationDialog()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.lr2_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            // Обробка натискань на елементи меню
            R.id.color_black -> {
                changeBackgroundColor(R.color.black)
                true
            }
            R.id.color_white -> {
                changeBackgroundColor(R.color.white)
                true
            }
            R.id.color_red -> {
                changeBackgroundColor(R.color.red)
                true
            }
            R.id.color_green -> {
                changeBackgroundColor(R.color.green)
                true
            }
            R.id.color_blue -> {
                changeBackgroundColor(R.color.blue)
                true
            }
            R.id.color_yellow -> {
                changeBackgroundColor(R.color.yellow)
                true
            }
            R.id.color_purple -> {
                changeBackgroundColor(R.color.purple)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // Метод для зміни кольору фону активності
    private fun changeBackgroundColor(colorResId: Int) {
        val rootView = findViewById<View>(R.id.main)
        rootView.setBackgroundColor(ContextCompat.getColor(this, colorResId))
    }

    // Метод для зміни кольору фону у TextView
    private fun changeBGColorText(colorResId: Int) {
        textView.setBackgroundColor(ContextCompat.getColor(this, colorResId))
    }

    // Метод для зміни кольору тексту у TextView
    /*private fun changeTextColor(colorResId: Int) {
        textView.setTextColor(ContextCompat.getColor(this, colorResId))
    }*/

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    // Обробка вибору в контекстному меню
    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.color_black -> {
                changeBGColorText(R.color.black)
                true
            }
            R.id.color_white -> {
                changeBGColorText(R.color.white)
                true
            }
            R.id.color_red -> {
                changeBGColorText(R.color.red)
                true
            }
            R.id.color_green -> {
                changeBGColorText(R.color.green)
                true
            }
            R.id.color_blue -> {
                changeBGColorText(R.color.blue)
                true
            }
            R.id.color_yellow -> {
                changeBGColorText(R.color.yellow)
                true
            }
            R.id.color_purple -> {
                changeBGColorText(R.color.purple)
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    private fun showConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Confirmation")
        builder.setMessage("Do you really want to switch to Activity 2?")

        builder.setPositiveButton("Yes") { dialog, which ->
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }

        builder.setNegativeButton("No") { dialog, which ->
            dialog.dismiss()
        }

        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
}